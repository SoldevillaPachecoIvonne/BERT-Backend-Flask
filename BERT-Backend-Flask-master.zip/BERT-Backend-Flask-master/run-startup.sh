#!/bin/bash -x
. /home/ubuntu/BERT-Backend-Flask/run-venv.sh
