# BERT-Backend
## Pre-requisitos 🔧

- Ubicarse en el proyecto
- Ejecutar:
```
pip install -r requirements.txt
```
- python main.py